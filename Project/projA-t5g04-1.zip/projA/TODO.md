# CGRA

## TO DO:

- [x] 1. Novas primitivas (5 valores)
    - [x] 1.1. Criação de um prisma sem topos (2.5 valores)
    - [x] 1.2. Criação de um cilindro sem topos (2.5 valores)

- [ ] 2. Criação de objetos compostos (8 valores)
    - [x] 2.1. Árvore, MyTree (2 valores)
    - [x] 2.2. Arvoredo, MyTreeGroupPatch/MyTreeRowPatch (2 valores)
    - [ ] 2.3. Casa, MyHouse (2 valores)
    - [x] 2.4. Colina, MyVoxelHill (2 valores)
    
- [x] 3. Criação de cubemap (2 valores)

- [ ] 4. Cena final (3 valores)
    - [ ] 4.1. Composição da cena (1 valor)
    - [ ] 4.2. Materiais (1 valor)
    - [ ] 4.3. Modo dia e noite (1 valor)



